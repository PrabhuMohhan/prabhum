package com.wipro.service;


	import java.util.Scanner;

	import com.wipro.bean.proj;

	public class prr 
	{
	Scanner s=new Scanner(System.in);
	proj sc=new proj();
	public proj getprr()
	{
	System.out.println("enter id");
	sc.setId(s.nextInt());
	System.out.println("enter name");
	sc.setName(s.next());
	System.out.println("enter date");
	sc.setDate(s.next());
	System.out.println("enter dc");
	sc.setDc(s.next());
	System.out.println("enter dept");
	sc.setDept(s.next());
	System.out.println("enter bas");
	sc.setBas(s.nextFloat());
	System.out.println("enter hra");
	sc.setHra(s.nextDouble());
	System.out.println("enter it");
	sc.setIt(s.nextFloat());
	System.out.println("enter da");
	sc.setDa(s.nextFloat());
	System.out.println("enter designation");
	sc.setDesignation(s.next());
	 sc.setSal(sc.getBas()+sc.getHra()+sc.getDa()-sc.getIt());
	return sc;
	}
	}

