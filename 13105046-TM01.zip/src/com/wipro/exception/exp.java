package com.wipro.exception;

public class exp extends Exception{
		
		
		String str;
		public void Excbasic(String string)
		{
		str=string+"should greater than 0";
		}
		
		public String tostring()
		{
			return str;
		}
		}
		
		



