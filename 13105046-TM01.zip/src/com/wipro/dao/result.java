package com.wipro.dao;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

import com.wipro.bean.proj;
import com.wipro.service.prr;

public class result 
{


private static Object proj;

public static void main(String[]args)
{
	Scanner s=new Scanner(System.in);
	{
		System.out.println("enter number of employees");
				int scount=s.nextInt();
	ArrayList<proj>als=new ArrayList<proj>();
	{
		prr s1=new prr();
		for(int i1=0;i1<scount;i1++)
	als.add(s1.getprr());
		{
			Iterator<proj>ite=als.iterator();
			
		
		while(ite.hasNext())
		{
         proj is=ite.next();
         System.out.println(is.getId());
         System.out.println(is.getName());
         System.out.println(is.getDate());
         System.out.println(is.getDc());
         System.out.println(is.getDept());
         System.out.println(is.getBas());
         System.out.println(is.getHra());
         System.out.println(is.getIt());
         System.out.println(is.getDa());
         System.out.println(is.getDesignation());
         System.out.println("enter the id you wanna cal sal");
       int k=s.nextInt();
        if(k==is.getId())
        {
        	is.getSal();
        	System.out.println(is.getSal());
        	
        }
		}
		}
}
}}
}

